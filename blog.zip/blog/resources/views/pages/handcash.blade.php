@extends('layout')
@section('content')

<section id="form"><!--form-->
		<div class="container">
			<div class="row">
				<div class="col-sm-3 col-sm-offset-1">
					<div class="login-form">
						<h1>Thanks for order</h1>						
						<h2>We will contact as soon as possible</h2>
					</div>
				</div>				
				<div class="col-sm-4">
					<div class="signup-form">
												
					</div>
				</div>
			</div>
		</div>
	</section><!--/form-->

@endsection